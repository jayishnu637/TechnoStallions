from django.contrib import admin
from django.urls import path
from food import views

urlpatterns = [
    path('', views.index, name = 'food'),
    path("about", views.about, name='about'),
    path("contact", views.contact, name='contact'),
    path("donor", views.donor, name='donor'), 
    path("organisation", views.organisation, name='organisation'), 
    path("supplier", views.supplier, name='supplier'), 
    path("list", views.list, name='list'),
]
