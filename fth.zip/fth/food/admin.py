from django.contrib import admin
from food.models import Donor, Supplier, Contact, Organisation
# Register your models here.
admin.site.register(Donor)
admin.site.register(Supplier)
admin.site.register(Contact)
admin.site.register(Organisation)